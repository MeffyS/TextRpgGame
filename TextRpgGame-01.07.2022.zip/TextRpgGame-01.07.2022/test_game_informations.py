def game_informations():
    print("Hello dear player. Here is some game informations for you.")
    print("This is advanced RPG game, created by Meffy")
    print("Here you will explore map, fight with mobs, using skills")
    print("upgrade equipment, open chest, visit dungeons and city")
    print("gamble coins, use bank system, and a lot more thigs")
    print("Sooo, click number [1] and let's go")
    print("Good luck and have with my game ;)")

    pass
